const db = require('./database');
const { Sequelize, DataTypes } = require('sequelize');

// Define the schema
const Config = db.define('Config', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING, allowNull: false },
    type: { type: DataTypes.STRING },
    registration: { type: DataTypes.STRING, unique: true },
    country: DataTypes.STRING,
    region: DataTypes.STRING,
    department: DataTypes.STRING,
    borough: DataTypes.STRING,
    city: DataTypes.STRING,
    postal_code: DataTypes.NUMBER,
    address: DataTypes.STRING,
    motto: DataTypes.STRING,
    chief: DataTypes.STRING,
    email: { type: DataTypes.STRING, unique: true },
    phone: { type: DataTypes.STRING, unique: true }
}, { tableName: 'config', timestamps: false });

module.exports = Config;