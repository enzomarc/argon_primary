const db = require('./database');
const { Sequelize, DataTypes } = require('sequelize');

// Define the schema
const Staff = db.define('Staff', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    first_name: { type: DataTypes.STRING, allowNull: false },
    last_name: DataTypes.STRING,
    birthdate: { type: DataTypes.DATE, allowNull: false },
    birthplace: { type: DataTypes.STRING, allowNull: false },
    gender: { type: DataTypes.STRING, allowNull: false },
    address: { type: DataTypes.STRING, allowNull: false },
    phone: { type: DataTypes.STRING, unique: true, allowNull: false },
    email: { type: DataTypes.STRING, unique: true },
    avatar: DataTypes.STRING,
    type: { type: DataTypes.STRING, allowNull: false },
    createdAt: DataTypes.DATE,
    updatedAt: DataTypes.DATE
}, { tableName: 'staff' });

module.exports = Staff;