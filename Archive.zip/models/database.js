const { Sequelize } = require('sequelize');

let sequelize = new Sequelize('argon', 'root', 'root', { host: 'localhost', dialect: 'mysql' });

module.exports = sequelize;